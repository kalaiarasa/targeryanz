<?php
session_start();
$_SESSION['c_code']='1234';
include '../db_connect.php';
//echo $_POST['a_no'];
$sql="delete from student_info where a_no=? and c_code=?";
if($stmt=$conn->prepare($sql))
{
    $stmt->bind_param("ss",$_POST['a_no'],$_SESSION['c_code']);
    if($stmt->execute())
    {
        echo "success";
    }
    else
    {
        echo $conn->error;
    }
}
else
{
    echo $conn->error;
}
?>