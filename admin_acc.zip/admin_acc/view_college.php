<?php

?>
<html>
<head>
</head>
<body>
    <form action="student_details.php" method="post">
    <input type="number" name="c_code">
    <input type="submit" value="submit">
    </form>
</body>
</html>
